using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using System.Drawing;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: ExtensionApplication(typeof(Techbase.Blocks.Plugin))]
[assembly: CommandClass(typeof(Techbase.Blocks.Plugin))]

namespace Techbase.Blocks;

public sealed partial class Plugin : IExtensionApplication
{
    internal static Settings Preferences { get; private set; } = Settings.Read();
    internal static Catalog? Blocks { get; private set; }
    private Stationslocaties.StationTableUpdates? stationTableUpdates;
    private static StationLocationsPanel? stationLocationsPanel;
    private static PaletteSet? palette;
    private static WorkspacePanel? workspace;
    private static BlocksPanel? panel;
    private static LightmastPanel? lightmastPanel;
    private static KabelCheckerPanel? kabelCheckerPanel;
    private static DirectionPanel? directionPanel;
    private static SettingsPanel? settingsPanel;
    private static KabelgeulPanel? kabelgeulPanel;
    internal static LightmastRequest? PendingLightmast { get; set; }
    internal static DirectionInfoRequest? PendingDirectionInfo { get; set; }
    internal static StationActionRequest? PendingStationAction { get; set; }
    internal static string ContentsRoot => Directory.GetParent(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)!)!.FullName;
    internal static string DefaultPalette => Path.Combine(ContentsRoot, "Assets", "Techbase toolpallete.xtp");
    public void Initialize()
    {
        try { Typography.EnsureInstalled(); Reload(); }
        catch (System.Exception ex) { AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nTechbase Blocks: " + ex.Message); }
        try { stationTableUpdates = new Stationslocaties.StationTableUpdates(); stationTableUpdates.Initialize(); }
        catch (System.Exception ex) { AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nStationlocaties: " + ex.Message); }
    }
    public void Terminate() { stationTableUpdates?.Terminate(); stationLocationsPanel?.Dispose(); workspace?.Dispose(); kabelgeulPanel?.Dispose(); settingsPanel?.Dispose(); directionPanel?.Dispose(); kabelCheckerPanel?.Dispose(); lightmastPanel?.Dispose(); panel?.Dispose(); palette?.Dispose(); }
    internal static void Reload(string? path = null)
    {
        var candidate = new Catalog(path ?? Preferences.PalettePath ?? DefaultPalette);
        Blocks = candidate;
        if (path != null) { Preferences.PalettePath = path; Preferences.Save(); }
        panel?.RefreshTools();
    }
    internal static void UpdateSettings()
    {
        try { Preferences.Save(); }
        catch (System.Exception ex) { AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nInstelling kon niet worden opgeslagen: " + ex.Message); }
        panel?.RefreshSettings();
        settingsPanel?.RefreshSettings();
    }
    internal static string ResetSettings()
    {
        var defaults = new Settings(); KabelgeulData.MigrateText(defaults);
        var catalog = new Catalog(DefaultPalette);
        if (File.Exists(Settings.FilePath)) File.Copy(Settings.FilePath, Settings.FilePath + ".before-reset-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff") + ".json");
        defaults.Save(); Preferences = defaults; Blocks = catalog;
        panel?.RefreshTools(); panel?.RefreshSettings(); directionPanel?.RefreshSettings(); settingsPanel?.RefreshSettings(); kabelgeulPanel?.RefreshSettings();
        return "Plugininstellingen en Kabelgeul-standaardteksten hersteld. Vorige instellingen bewaard als kopie.";
    }
    [CommandMethod("TECHBASE", CommandFlags.Modal)]
    public void Show()
    {
        try
        {
            if (Blocks == null) Reload();
            if (palette == null)
            {
                palette = new PaletteSet("Techbase", new Guid("F0674EA1-D625-43F5-A0BA-016A165B0D66"))
                {
                    Style = PaletteSetStyles.ShowAutoHideButton | PaletteSetStyles.ShowCloseButton | PaletteSetStyles.ShowPropertiesMenu,
                    MinimumSize = new Size(360, 640), Size = new Size(420, 860),
                    KeepFocus = false, DockEnabled = DockSides.Left | DockSides.Right
                };
                panel = new BlocksPanel();
                lightmastPanel = new LightmastPanel();
                kabelCheckerPanel = new KabelCheckerPanel(ExpandChecker, () => workspace?.Navigate(0));
                directionPanel = new DirectionPanel();
                settingsPanel = new SettingsPanel();
                kabelgeulPanel = new KabelgeulPanel(ExpandChecker);
                stationLocationsPanel = new StationLocationsPanel();
                workspace = new WorkspacePanel(panel, lightmastPanel, kabelCheckerPanel, directionPanel, settingsPanel, kabelgeulPanel, stationLocationsPanel);
                palette.Add("Werkplaats", workspace);
            }
            palette.Visible = true;
        }
        catch (System.Exception ex) { Error(ex); }
    }
    [CommandMethod("TBSTATIONLOCATIES", CommandFlags.Modal)]
    public void StationsTab()
    {
        Show();
        workspace?.Navigate(6);
        stationLocationsPanel?.RefreshSheets();
    }

    [CommandMethod("STATIONLOCATIES", CommandFlags.Modal)]
    public void StationLocations() => StationsTab();

    [CommandMethod("TBSTATIONBEHEER", CommandFlags.Modal)]
    public void StationManager() => StationsTab();

    [CommandMethod("TBSTATIONACTIE", CommandFlags.Modal)]
    public void ExecuteStationAction()
    {
        var pending = PendingStationAction;
        PendingStationAction = null;
        if (pending == null) return;
        var document = AcApp.DocumentManager.MdiActiveDocument;
        if (document == null || document != pending.Document)
        {
            document?.Editor.WriteMessage("\nStationlocaties: de actieve tekening is gewijzigd. Kies de actie opnieuw.");
            stationLocationsPanel?.RefreshSheets();
            return;
        }
        try { new Stationslocaties.StationLocationController().ShowStationLocations(pending.Action, pending.SheetName); }
        catch (System.Exception ex) { Error(ex); }
        finally { stationLocationsPanel?.RefreshSheets(); }
    }

    [CommandMethod("TBSTATIONXREFSTART", CommandFlags.Session)]
    public void StationXrefStart()
    {
        try { new Stationslocaties.StationLocationController().StartStationReference(); }
        catch (System.Exception ex) { Error(ex); }
    }

    [CommandMethod("TBLAAG", CommandFlags.Modal)]
    public void Toggle()
    {
        Preferences.InheritLayer = !Preferences.InheritLayer;
        UpdateSettings();
        AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nTechbase: laag overnemen " + (Preferences.InheritLayer ? "AAN" : "UIT") + "." +
            (Preferences.UseChosenBlockLayer ? " Gekozen blocklaag heeft voorrang zolang die aanstaat." : ""));
    }
    [CommandMethod("TBRTACHTER", CommandFlags.Modal)]
    public void RtBack()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        if (doc == null) return;
        try
        {
            using var tx = doc.Database.TransactionManager.StartTransaction();
            var count = RtDrawOrder.Apply(doc.Database, tx);
            tx.Commit(); doc.Editor.Regen();
            doc.Editor.WriteMessage($"\nRT-maskers: {count} blockdefinities bijgewerkt; wipeouts staan helemaal achteraan.");
        }
        catch (System.Exception ex) { Error(ex); }
    }
    [CommandMethod("TBBLOCKTEKSTLAAG", CommandFlags.Modal | CommandFlags.UsePickSet)]
    public void RepairBlockTextLayers()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        if (doc == null) return;
        try
        {
            var selection = doc.Editor.SelectImplied();
            if (selection.Status != Autodesk.AutoCAD.EditorInput.PromptStatus.OK)
                selection = doc.Editor.GetSelection(new Autodesk.AutoCAD.EditorInput.PromptSelectionOptions
                { MessageForAdding = "\nSelecteer pluginblocks waarvan de tekst de blocklaag moet volgen: " },
                new Autodesk.AutoCAD.EditorInput.SelectionFilter(new[]
                { new Autodesk.AutoCAD.DatabaseServices.TypedValue((int)Autodesk.AutoCAD.DatabaseServices.DxfCode.Start, "INSERT") }));
            if (selection.Status != Autodesk.AutoCAD.EditorInput.PromptStatus.OK) return;
            var result = BlockAttributeLayers.Repair(doc.Database, selection.Value.GetObjectIds());
            doc.Editor.Regen();
            doc.Editor.WriteMessage($"\nBlocktekstlaag: {result.Changed} attributen hersteld; {result.Skipped} objecten overgeslagen. Tekstwaarden en opmaak behouden.");
        }
        catch (System.Exception ex) { Error(ex); }
    }
    [CommandMethod("TBRICHTINGEN", CommandFlags.Modal)]
    public void ShowDirections() { Show(); workspace?.Navigate(3); }
    private static int? PromptDirection()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        if (doc == null) return null;
        var result = doc.Editor.GetInteger(new Autodesk.AutoCAD.EditorInput.PromptIntegerOptions("\nRichting (1 t/m 12): ")
        { LowerLimit = 1, UpperLimit = 12, DefaultValue = Preferences.SelectedDirectionNumber, AllowNone = true });
        return result.Status == Autodesk.AutoCAD.EditorInput.PromptStatus.OK ? result.Value :
            result.Status == Autodesk.AutoCAD.EditorInput.PromptStatus.None ? Preferences.SelectedDirectionNumber : null;
    }
    private static void ReportDirection(string message)
    { directionPanel?.Report(message); AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\n" + message); }
    [CommandMethod("TBTEKENRICHTING", CommandFlags.Modal)]
    public void DrawDirection()
    {
        try
        {
            var number = PromptDirection(); if (!number.HasValue) return;
            var doc = AcApp.DocumentManager.MdiActiveDocument; if (doc == null) return;
            ReportDirection(DirectionLines.Draw(doc, number.Value));
        }
        catch (System.Exception ex) { ReportDirection(ex.Message); }
    }
    [CommandMethod("TBMAAKRICHTING", CommandFlags.Modal | CommandFlags.UsePickSet)]
    public void ConvertDirection()
    {
        try
        {
            var number = PromptDirection(); if (!number.HasValue) return;
            var doc = AcApp.DocumentManager.MdiActiveDocument; if (doc == null) return;
            var selection = doc.Editor.SelectImplied();
            if (selection.Status != Autodesk.AutoCAD.EditorInput.PromptStatus.OK)
                selection = doc.Editor.GetSelection(new Autodesk.AutoCAD.EditorInput.PromptSelectionOptions
                { MessageForAdding = "\nSelecteer polylines of losse lijnen om om te zetten: " },
                new Autodesk.AutoCAD.EditorInput.SelectionFilter(new[]
                { new Autodesk.AutoCAD.DatabaseServices.TypedValue((int)Autodesk.AutoCAD.DatabaseServices.DxfCode.Start, "LWPOLYLINE,POLYLINE,LINE") }));
            if (selection.Status != Autodesk.AutoCAD.EditorInput.PromptStatus.OK) { ReportDirection("Omzetten geannuleerd."); return; }
            using var working = new WorkingDatabaseScope(doc.Database);
            var result = DirectionLines.Convert(doc.Database, selection.Value.GetObjectIds(), number.Value);
            doc.Editor.Regen();
            ReportDirection($"{result.Changed} objecten omgezet naar richting {number.Value}. " +
                $"{result.LinesConverted} losse lijnen werden polylines; {result.Skipped} objecten overgeslagen." +
                (result.Skipped > 0 ? " Alleen bewerkbare 2D-polylines en LINE-lijnen in de huidige tekenruimte worden omgezet." : ""));
        }
        catch (System.Exception ex) { ReportDirection(ex.Message); }
    }
    [CommandMethod("TBRICHTINGVALIDATE", CommandFlags.Modal)]
    public void ValidateDirectionLines()
    {
        try { DirectionLineDiagnostics.Run(); }
        catch (System.Exception ex)
        {
            Error(ex); var folder = Environment.GetEnvironmentVariable("TECHBASE_TEST_OUTPUT");
            if (folder != null) { Directory.CreateDirectory(folder); File.WriteAllText(Path.Combine(folder, "richting-failure.log"), ex.ToString()); }
        }
    }
    [CommandMethod("TBTEKSTLS", CommandFlags.Modal)]
    public void PlaceLSText() => ExecuteDirectionText(false, null);
    [CommandMethod("TBTEKSTOV", CommandFlags.Modal)]
    public void PlaceOVText() => ExecuteDirectionText(true, null);
    [CommandMethod("TBTEKSTKOPIE", CommandFlags.Modal)]
    public void CopyDirectionText() => ExecuteDirectionText(false, true);
    [CommandMethod("TBTEKSTVERPLAATS", CommandFlags.Modal)]
    public void MoveDirectionText() => ExecuteDirectionText(false, false);
    private static void ExecuteDirectionText(bool ov, bool? copy)
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument; if (doc == null) return;
        try { ReportDirection(copy.HasValue ? DirectionText.Run(doc, copy.Value) : DirectionText.PlaceTemplate(doc, ov)); }
        catch (System.Exception ex) { ReportDirection(ex.Message); }
    }
    [CommandMethod("TBTEKSTVALIDATE", CommandFlags.Modal)]
    public void ValidateDirectionText()
    {
        try { DirectionTextDiagnostics.Run(); }
        catch (System.Exception ex)
        {
            Error(ex); var folder = Environment.GetEnvironmentVariable("TECHBASE_TEST_OUTPUT");
            if (folder != null) { Directory.CreateDirectory(folder); File.WriteAllText(Path.Combine(folder, "tekst-failure.log"), ex.ToString()); }
        }
    }
    [CommandMethod("TBKABELCHECK", CommandFlags.Modal)]
    public void KabelChecker()
    {
        Show();
        if (palette == null) return;
        workspace?.Navigate(2);
        ExpandChecker();
    }
    private static void ExpandChecker()
    {
        if (palette == null) return;
        var screen = System.Windows.Forms.Screen.FromPoint(palette.Location).WorkingArea;
        palette.Dock = DockSides.None;
        palette.Size = new Size(Math.Min(900, screen.Width - 40), Math.Min(910, screen.Height - 40));
        palette.Location = new Point(
            Math.Clamp(palette.Location.X, screen.Left + 20, Math.Max(screen.Left + 20, screen.Right - palette.Size.Width - 20)),
            Math.Clamp(palette.Location.Y, screen.Top + 20, Math.Max(screen.Top + 20, screen.Bottom - palette.Size.Height - 20)));
        palette.Visible = true;
    }
    [CommandMethod("TBRICHTINGINFO", CommandFlags.Modal)]
    public void DirectionInfo()
    {
        var request = PendingDirectionInfo;
        PendingDirectionInfo = null;
        if (request == null) { KabelChecker(); kabelCheckerPanel?.ReportInfo("Selecteer een richting en klik onderin op Richting-info plaatsen."); return; }
        if (request.Document != AcApp.DocumentManager.MdiActiveDocument)
        { kabelCheckerPanel?.ReportInfo("De actieve tekening is veranderd; selecteer de richting opnieuw."); return; }
        try
        {
            var message = DirectionInfoService.Place(request);
            kabelCheckerPanel?.ReportInfo(message); request.Document.Editor.WriteMessage("\n" + message);
        }
        catch (System.Exception ex) { Error(ex); kabelCheckerPanel?.ReportInfo(ex.Message); }
    }
    [CommandMethod("TBLICHTMAST", CommandFlags.Modal)]
    public void Lightmasts()
    {
        var request = PendingLightmast;
        PendingLightmast = null;
        if (request == null) { Show(); workspace?.Navigate(1); return; }
        if (request.Document != AcApp.DocumentManager.MdiActiveDocument)
        { AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nDe actieve tekening is veranderd. Kies de xref opnieuw."); return; }
        try { var message = LightmastCommands.Execute(request); lightmastPanel?.Report(message); }
        catch (System.Exception ex) { Error(ex); lightmastPanel?.Report(ex.Message); }
    }
    [CommandMethod("TBPLAATS", CommandFlags.Modal)]
    public void Insert()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        if (doc == null) return;
        try
        {
            if (Blocks == null) Reload();
            var code = doc.Editor.GetString("\nTool-ID: ");
            if (code.Status != Autodesk.AutoCAD.EditorInput.PromptStatus.OK) return;
            var tool = Blocks!.Tools.FirstOrDefault(t => t.Id.Equals(code.StringResult, StringComparison.OrdinalIgnoreCase));
            if (tool == null) { doc.Editor.WriteMessage("\nOnbekende tool-ID. Gebruik TECHBASE."); return; }
            do { if (!BlockInserter.Place(doc, Blocks, tool, Preferences)) break; } while (Preferences.Repeat);
        }
        catch (System.Exception ex) { Error(ex); }
    }
    [CommandMethod("TBHERLAAD", CommandFlags.Modal)]
    public void Refresh()
    {
        try { Reload(); AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nTechbase-palette opnieuw ingelezen."); }
        catch (System.Exception ex) { Error(ex); }
    }
    [CommandMethod("TBVALIDATE", CommandFlags.Modal)]
    public void Validate()
    {
        try { Diagnostics.Run(Blocks ?? new Catalog(DefaultPalette)); }
        catch (System.Exception ex)
        {
            Error(ex);
            var folder = Environment.GetEnvironmentVariable("TECHBASE_TEST_OUTPUT");
            if (folder != null) { Directory.CreateDirectory(folder); File.WriteAllText(Path.Combine(folder, "failure.log"), ex.ToString()); }
        }
    }
    [CommandMethod("TBMASTVALIDATE", CommandFlags.Modal)]
    public void ValidateLightmasts()
    {
        try { LightmastDiagnostics.Run(); }
        catch (System.Exception ex)
        {
            Error(ex); Directory.CreateDirectory(LightmastDiagnostics.Output);
            File.WriteAllText(Path.Combine(LightmastDiagnostics.Output, "lichtmast-failure.log"), ex.ToString());
        }
    }
    [CommandMethod("TBKABELVALIDATE", CommandFlags.Modal)]
    public void ValidateKabelChecker()
    {
        try { KabelCheckerDiagnostics.Run(); }
        catch (System.Exception ex)
        {
            Error(ex); Directory.CreateDirectory(LightmastDiagnostics.Output);
            File.WriteAllText(Path.Combine(LightmastDiagnostics.Output, "kabelchecker-failure.log"), ex.ToString());
        }
    }
    [CommandMethod("TBKABELINPUTTEST", CommandFlags.Modal)]
    public void TestKabelInput()
    {
        if (Environment.GetEnvironmentVariable("TECHBASE_TEST_OUTPUT") == null) return;
        try
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return;
            var options = new Autodesk.AutoCAD.EditorInput.PromptKeywordOptions("\nKabelselectietest: ");
            options.Keywords.Add("Volledig"); options.Keywords.Add("Knip");
            var mode = doc.Editor.GetKeywords(options);
            var result = mode.StringResult == "Knip"
                ? Enexis.KabelChecker.AutoCAD.DirectionPolylineSelection.PickPolylinePartToVirtualCut("4*150mm2 Al")
                : Enexis.KabelChecker.AutoCAD.DirectionPolylineSelection.PickSinglePolyline("4*150mm2 Al");
            var expected = mode.StringResult == "Knip" ? 75 : 100;
            if (result.Cancelled || Math.Abs(result.LengthMeters - expected) > 1e-8 || result.SuggestedDirectionNumber != 3)
                throw new InvalidOperationException("Kabelselectietest mislukt: " + result.Message);
            doc.Editor.WriteMessage(mode.StringResult == "Knip" ? "\nKABEL_CUT_INPUT_PASS" : "\nKABEL_FULL_INPUT_PASS");
        }
        catch (System.Exception ex) { Error(ex); }
    }
    [CommandMethod("TBINFOSETUPTEST", CommandFlags.Modal)]
    public void TestInfoSetup()
    {
        if (Environment.GetEnvironmentVariable("TECHBASE_TEST_OUTPUT") != null) DirectionInfoDiagnostics.QueueFixture();
    }
    [CommandMethod("TBMASTAREATEST", CommandFlags.Modal)]
    public void TestDrawArea()
    {
        if (Environment.GetEnvironmentVariable("TECHBASE_TEST_OUTPUT") == null) return;
        try
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return;
            var prompt = new Autodesk.AutoCAD.EditorInput.PromptKeywordOptions("\nGebiedstest: ");
            prompt.Keywords.Add("Tekenen"); prompt.Keywords.Add("Polyline");
            var mode = doc.Editor.GetKeywords(prompt);
            var area = mode.StringResult == "Polyline" ? LightmastCommands.SelectBoundary(doc.Editor, doc.Database) : LightmastCommands.DrawBoundary(doc.Editor);
            if (area == null) { doc.Editor.WriteMessage("\nAREA_CANCEL_PASS"); return; }
            if (!area.Contains(new Autodesk.AutoCAD.Geometry.Point3d(5, 5, 0)) || area.Contains(new Autodesk.AutoCAD.Geometry.Point3d(15, 5, 0)))
                throw new InvalidOperationException("Gebiedstest mislukt.");
            doc.Editor.WriteMessage("\nAREA_INPUT_PASS");
        }
        catch (System.Exception ex) { Error(ex); }
    }
    private static void Error(System.Exception ex) => AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nTechbase: " + ex.Message);
}
