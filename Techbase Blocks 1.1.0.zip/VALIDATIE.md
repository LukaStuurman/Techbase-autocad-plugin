# Controle versie 1.1.0 — 9 oktober 2026

De plugin is gebouwd en lokaal geïnstalleerd. De automatische controles draaien in de echte AutoCAD 2026 Core Console (ACADVER 25.1), zonder de bron-DWG of gebruikersinstellingen te wijzigen.

## Nieuwe tab Lichtmasten

De functionaliteit van `LICHTMAST.LSP` is opgenomen in een tweede tab. De nieuwe tab biedt xref-invoegingen, lichtmastlagen, een optioneel blockfilter en gebiedsopties bestaande gesloten polyline, alles en zelf polygoon tekenen.

- **28 geslaagde servicecontroles** met een zelfstandig gemaakte test-xref: meerdere invoegingen apart kiezen; lagen/blocktypen filteren; niet-uniforme xref-schaal, verplaatsing, 90° rotatie, xref-basispunt en hoogte; een genest block met eigen rotatie en schaal; laag-0-overerving; gebiedsselectie in wereldcoördinaten; samengesteld block en zijn interne onderdelen eenmaal tellen; herhaling zonder dubbelen.
- Het getekende symbool volgt de Lisp: drie polylijnen, cirkeldiameter 1,1977, breedte 0,2, laag 0 intern en referenties op Bestaand met kleur ByLayer en schaal 1.
- Controles op rechte, concave en ronde gebieden, positieve/negatieve bulges, exacte booggrenzen, grenspunten, open polylines en zelfkruisende rechte polygonen.
- **4 geslaagde invoercontroles via de echte gebiedsprompts**: klikken en Enter sluiten, Terug/Sluiten tijdens tekenen, bestaande polyline aanwijzen en zelf tekenen in een 90° gedraaid UCS.
- De opgeslagen DWG is opnieuw geopend en de symboollagen en wereldposities zijn teruggelezen. De xref-DWG heeft vóór en na uitvoering dezelfde SHA-256.
- De geïnstalleerde versie 1.1.0 laadt op het nieuwe TBMASTVALIDATE-commando automatisch, zonder NETLOAD, en doorloopt dezelfde 28 service- en 4 gebiedsinvoercontroles. De installatie werkt bestaande startregistraties van uitsluitend deze plugin bij, met een backup van de oude waarden.

Bewijs staat in `validation/Lichtmasten/validatie-lichtmasten.json`, `gebiedscommando.json`, de test-xref, `Lichtmasten - controle.dwg`/`.dxf` en `validation/lightmasts.log`. De gelezen Lisp is apart bewaard in `Reference/LICHTMAST.LSP`, SHA-256 `AF52E8C80F4C0CA2B0D0C5484BBF6AA63A21EAA01C521D0D3D13A0BEE07B5BF5`.

De volledige modeless tab is nog niet visueel getest in de AutoCAD/Civil 3D-gebruikersinterface. De praktijkcontrole hieronder blijft ook voor deze tab van toepassing: xref kiezen, lagen en blocktypen aanvinken, iedere gebiedsoptie gebruiken, Esc en Undo controleren, en wisselen tussen tekeningen/model/papier. AutoCAD/Civil 3D 2025 en 2027 zijn hier niet als testhost beschikbaar.

## Uitgevoerde controles

- Twee afzonderlijke Release-builds, beide zonder waarschuwingen of fouten: Autodesk API **25.0.1 / .NET 8** en **26.0.0 / .NET 10**.
- **58 paletknoppen**, **53 unieke blockdefinities**, waarvan **13 knoppen een dynamisch block gebruiken**. Dubbele namen zoals Zekering blijven aparte paletknoppen, volgens de XTP.
- **410 geslaagde controles**: importeren en plaatsen van alle tools, paletfactoren waaronder Flatkast 0,5, attributen, beide explode-tools, dynamische varianten waar de bron keuzewaarden aanbiedt, laagtoewijzing en opnieuw openen van de opgeslagen DWG.
- Laagdetectie bij een lijn, polyline, cirkel, binnen/buiten tolerantie, 3D-afstand, meerdere gelijke lagen, verschillende lagen op een kruising, cursorselectie van tekst en bescherming van een vergrendelde laag.
- Annuleren van een transactie laat geen blockreferentie achter. De huidige tekenlaag blijft behouden.
- **7 aanvullende checks via het daadwerkelijke TBPLAATS/TBLAAG-commando**: automatische laag aan, automatische laag uit, expliciete Object-keuze, huidige laag behouden, laag bij een 90° gedraaid UCS, juiste wereldcoördinaten bij dat UCS en Undo van de plaatsing.
- Instellingen tijdens tests zijn geïsoleerd in de validatiemap. De oude Lisp-reactors worden niet verwijderd of gewijzigd.
- De geïnstalleerde bundle is zonder NETLOAD via het geregistreerde commando automatisch geladen in AutoCAD 2026 Core Console; ook die run doorloopt alle 410 controles.

Bewijs: `validation/validatie.json`, `validation/commands.json`, de bijbehorende logbestanden en `validation/Alle blocks - controle.dwg` plus `.dxf`. De bronmomentopname is herkenbaar aan SHA-256 in `Contents/Assets/bronversies.json`.

Bij het openen van de bron-DWG meldt de geïnstalleerde Civil Object Enabler ontbrekende componenten/catalogi in deze Core Console-omgeving. De gebruikte blockdefinities zijn desondanks afzonderlijk geïmporteerd en alle bovengenoemde controles slagen. De plugin wijzigt die computerinstellingen niet.

## Praktijktests die nog nodig zijn

| Product | Build | Engine/commando getest | Volledige gebruikersinterface getest |
| --- | --- | --- | --- |
| AutoCAD 2025 | Geslaagd, API 25.0.1 | Niet beschikbaar op deze computer | Nog uitvoeren |
| Civil 3D 2025 | Zelfde R25-build | Niet uitgevoerd | Nog uitvoeren |
| AutoCAD 2026 | Geslaagd, R25 | Geslaagd in Core Console | Nog uitvoeren |
| Civil 3D 2026 | Zelfde R25-build | Geen aparte Civil-hosttest; Object Enabler is geen volledige Civil-test | Nog uitvoeren |
| AutoCAD 2027 | Geslaagd, API 26.0.0 | Niet beschikbaar op deze computer | Nog uitvoeren |
| Civil 3D 2027 | Zelfde R26-build | Niet uitgevoerd | Nog uitvoeren |

De compatibiliteitsindeling volgt de officiële Autodesk SDK-matrix. Dit is geen claim dat alle zes productcombinaties al praktisch zijn getest.

Korte praktijkcontrole per versie: open een kopie van een tekening, voer TBLOCKS uit, controleer zoeken en afbeeldingen, plaats BESTAANDE MOF op een polyline met de schakelaar aan/uit, plaats met Object op tekst of een Civil-object, bewerk een dynamisch block en een attribuut, annuleer en gebruik Undo. Herstart de toepassing en controleer dat de schakelaar bewaard is gebleven. Controleer herhaling en model-/papieromgeving. Bij een kruisende of samenvallende laag moet een keuzevraag verschijnen.
