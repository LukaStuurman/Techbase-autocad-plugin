# Techbase Blocks 1.0.0

Plaats de blocks uit de Techbase toolpalette via een doorzoekbaar paneel in AutoCAD en Civil 3D voor Windows.

## Installeren

1. Pak de zip uit. Laat de map `Techbase.Blocks.bundle` naast `Installeren.cmd` staan.
2. Sluit AutoCAD en Civil 3D. Dubbelklik op `Installeren.cmd`. Beheerdersrechten zijn niet nodig.
3. Start AutoCAD of Civil 3D en voer **TBLOCKS** uit.

De plugin staat daarna onder `%APPDATA%\Autodesk\ApplicationPlugins`. Bestaande bestanden van deze plugin worden bij opnieuw installeren eerst gekopieerd naar een backup. De installatie wijzigt de oorspronkelijke toolpalette, DWG en Lisp niet.

## Blocks plaatsen

- Zoek of kies een groep. Dubbelklik op een block of klik **Plaatsen**.
- Er verschijnt een voorbeeld aan de cursor. Klik op het invoegpunt. Object snaps blijven beschikbaar.
- Met **Laag van object overnemen** aan krijgt de nieuwe blockreferentie de laag van een lijn, polyline, boog, cirkel, spline, ellips of 3D-curve nabij het invoegpunt. Zoekafstand standaard: **0,05 tekeneenheden** (5 cm in een meter-tekening).
- Voor tekst, arceringen, blocks en Civil-objecten gebruikt de plugin de werkelijke objectselectie onder de cursor. Voor een expliciete keuze typ je tijdens plaatsen **Object** en klik je het bedoelde object. Bij een curve wordt het invoegpunt op de curve gezet. Deze expliciete optie werkt ook als de automatische schakelaar uit staat.
- Bij een kruising van verschillende lagen vraagt de plugin welk object bedoeld wordt; Enter gebruikt de palettelaag. Zonder object gebruikt de plugin de vaste laag uit de palette, of de huidige laag als de palette geen laag voorschrijft.
- Met de schakelaar uit gebruikt plaatsen de palettelaag. De huidige tekenlaag blijft in beide standen gelijk.
- Bij een vergrendelde laag breekt plaatsen af met een melding. De plugin ontgrendelt geen lagen.
- **Herhaald plaatsen** blijft het gekozen block plaatsen tot Esc. Met Undo kun je het plaatscommando, inclusief een eventuele reeks, terugnemen.
- Schaal, draaivragen, dynamische blockeigenschappen, attribuutwaarden en de twee explode-instellingen uit de XTP worden meegenomen. De interne vaste lagen van blockonderdelen blijven behouden; laag 0 erft de invoeglaag.

De schakelaar regelt plaatsingen vanuit deze plugin. De oorspronkelijke palette en gewone INSERT-commando's worden niet onderschept. De oude Lisp is hiervoor niet nodig. Als die Lisp nog actief is, kan hij zijn eigen gewone INSERT-commando's blijven behandelen.

## Bronnen en instellingen

De installatie bevat een kopie van de XTP, bijbehorende afbeeldingen en de benodigde bron-DWG. Hierdoor werkt de meegeleverde palette zonder de gedeelde Techbase-map. De kopie is een momentopname; bronhashes staan in `Contents/Assets/bronversies.json`. **Vernieuwen** leest de huidige geselecteerde XTP opnieuw. Kies **Bron...** om een andere XTP te gebruiken; daarbij worden de eigen DWG-paden uit die XTP gebruikt, met ondersteuning voor `%UserProfileFolder%` en relatieve paden.

Een blockdefinitie die al in de tekening bestaat wordt hergebruikt. Bestaande blocks worden niet opnieuw gedefinieerd of gewijzigd. Nieuwe blockdefinities worden afzonderlijk uit de bron-DWG geïmporteerd, inclusief dynamische eigenschappen en afhankelijkheden. Annuleren laat geen ingevoegd block achter. Invoegeenheden worden tussen block en tekening omgerekend als beide een eenheid hebben; de paletfactor (bijvoorbeeld Flatkast 0,5) wordt daarop toegepast.

Instellingen staan in `%APPDATA%\Techbase\Blocks\settings.json` en blijven bewaard na herstart.

## Commando's

| Commando | Functie |
| --- | --- |
| TBLOCKS | Open het blockpaneel |
| TBLAAG | Wissel automatische laagovername aan/uit |
| TBHERLAAD | Lees de geselecteerde XTP opnieuw |
| TBPLAATS | Intern plaatscommando, aangeroepen door het paneel |
| TBVALIDATE | Test in een aparte database; schrijft test-DWG, DXF en JSON onder `%LOCALAPPDATA%\Techbase\Blocks\Validation` |

## Versies en controle

Het pakket bevat twee afzonderlijk gebouwde DLL's: **R25 / .NET 8** voor AutoCAD en Civil 3D 2025/2026, en **R26 / .NET 10** voor 2027. De Autodesk autoloader kiest op productversie. Er worden alleen gewone AutoCAD-API's gebruikt, zonder Civil-specifieke DLL's. AutoCAD LT en Mac zijn geen doelplatformen.

Autodesk bevestigt de API/runtime-grens in [Managed .NET Compatibility](https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Customization/files/GUID-A6C680F2-DE2E-418A-A182-E4884073338A.htm). Het pakket beperkt 2027 expliciet tot R26.0; latere productreleases vragen opnieuw een compatibiliteitscontrole.

De concrete testresultaten en resterende praktijktests staan in `VALIDATIE.md` bij de broncode. Een succesvolle build vervangt geen test in iedere productversie.

## Opnieuw bouwen

Gebruik een .NET 10 SDK en voer `Build.ps1 -Dotnet <pad-naar-dotnet.exe>` uit. De build haalt Autodesk AutoCAD.NET API 25.0.1 en 26.0.0 via NuGet op. De Autodesk API-DLL's worden niet meegeleverd: die levert de hostapplicatie. De uitvoer staat in `dist` en in `Techbase Blocks 1.0.0.zip`.
