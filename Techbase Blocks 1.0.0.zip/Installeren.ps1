param([string]$Destination = (Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins\Techbase.Blocks.bundle'))
$ErrorActionPreference = 'Stop'
$bundle = Join-Path $PSScriptRoot 'Techbase.Blocks.bundle'
if (!(Test-Path -LiteralPath (Join-Path $bundle 'PackageContents.xml'))) { throw 'Techbase.Blocks.bundle ontbreekt naast dit installatiebestand.' }
$target = [IO.Path]::GetFullPath($Destination)
if (Test-Path -LiteralPath $target) {
    $manifest = Join-Path $target 'PackageContents.xml'
    if (!(Test-Path -LiteralPath $manifest)) { throw "Doelmap bevat geen herkenbare plugin: $target" }
    [xml]$existing = Get-Content -LiteralPath $manifest -Raw
    if ($existing.ApplicationPackage.UpgradeCode -ne '{38F92DB5-FD94-41EB-B73E-31DAC1BD784A}') { throw 'Doelmap behoort aan een andere plugin.' }
    $backup = $target + '.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
    Copy-Item -LiteralPath $target -Destination $backup -Recurse
}
New-Item -ItemType Directory -Path $target -Force | Out-Null
Copy-Item -Path (Join-Path $bundle '*') -Destination $target -Recurse -Force
Get-ChildItem -LiteralPath $target -Recurse -File | Unblock-File
Write-Host "Geïnstalleerd in: $target"
Write-Host 'Start AutoCAD of Civil 3D opnieuw en voer TBLOCKS uit.'
